CREATE PROCEDURE raiseSal(pempno IN NUMBER,psal OUT TAB_EMP.sal%TYPE)
  AS
  /*psal TAB_EMP.SAL%TYPE;*/
  BEGIN
    SELECT sal INTO psal FROM TAB_EMP where EMPNO=pempno;
    UPDATE TAB_EMP set SAL=SAL+100 WHERE EMPNO=pempno;
    dbms_output.put_line('涨薪前:'||psal||',>>>涨薪后:'||(psal+100));
  END;
/
